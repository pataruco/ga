// Try to do this by setting styles (.style)
// Remember to try one step at a time, testing each stage as you go!
// Follow the 3 E's pattern (Element, Event, Execution)

console.log('Hello FEWD ');
