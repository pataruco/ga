# Color Switcher Lab 🧪

This is your first JavaScript lab 🚀!

Following the 3 **E's pattern (Element, Event, Execution)** solve the following problems:

1. When user `click` on the gray button the `background-color` of the page should change to `gray`.
2. When user `click` on the white button the `background-color` of the page should change to `white`.

Happy coding!
