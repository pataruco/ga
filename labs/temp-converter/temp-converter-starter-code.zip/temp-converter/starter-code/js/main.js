// Write out the pseudo code first

// Determine which elements you'll need to select with
// document.getElementById

// Think about the even you'll need to watch for

// Think about how you will need to add the result of your calculation
// to the page


// Use the following formula to convert fahrenheit to celcius
// °C = (°F  -  32) * (5/9)

// For extra credit add another button that swaps the conversion around
// so you can covert Celcius to Fahrenheit too! :)
