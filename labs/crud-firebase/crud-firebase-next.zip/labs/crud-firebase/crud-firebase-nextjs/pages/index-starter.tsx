import Head from "next/head";
import Votes from "../components/votes-starter";

// TODO:
// 1. Add on firebase sdk - To Do
// 2. Add the ability to add a message - To Do
// 3. Add the ability to read messages from realtime database - To Do
// 4. Add the ability to upvote items on the message board - To Do
// 5. Add the ability to downvote items on the message board - To Do
// 6. Add the ability to delete items on the message board and realtime database - To Do

export default function Index() {
  return (
    <>
      <Head>
        <meta charSet="utf-8" />
        <title>Public Produce</title>
        <link href="css/normalize.css" rel="stylesheet" />
        <link href="css/style.css" rel="stylesheet" />
      </Head>
      <main>
        <section>
          <h1>
            Public Produce
            <span role="img" aria-labelledby="plant">
              {" "}
              &#x1F331;{" "}
            </span>
          </h1>
          <p>Got produce for anyone to pick and take? Let us know!</p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              console.log(e);
            }}
            id="message-form"
            className="mb-6"
          >
            <label htmlFor="message">What and where:</label>
            <textarea id="message" type="text" placeholder="Example: Sourdough in Hackney."></textarea>
            <button className="btn" type="submit">
              Post to board
            </button>
          </form>
        </section>
        <section>
          <h2>
            Produce Postings
            <span role="img" aria-labelledby="plant">
              {" "}
              &#x1F331;{" "}
            </span>
          </h2>
          <ul className="message-board">
            <Votes />
          </ul>
        </section>
      </main>
    </>
  );
}
