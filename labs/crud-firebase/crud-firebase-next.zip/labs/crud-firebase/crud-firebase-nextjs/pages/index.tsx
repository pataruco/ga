// Component imports:
import Head from "next/head";
import Votes from "../components/votes";

// Firebase and UUID:
import { generateUUID } from "../lib/generateUUID";
import { getDatabase, ref, set, onValue, child, get, push, update } from "firebase/database";
const db = getDatabase();

// ReactJS imports:
import { useEffect, useState } from "react";

const addMessageToRealtimeDB = async (message) => {
  const newRef = ref(db, `messages/${generateUUID()}`);
  const newMessage = {
    message: message,
    timestamp: Date.now(),
    votes: 0,
  };
  return await set(newRef, newMessage);
};

export default function Index() {
  const [allMessages, setAllMessages] = useState({});

  useEffect(() => {
    // Setting a listener 1x:
    const messagesRef = ref(db, "messages");

    onValue(messagesRef, (snapshot) => {
      // There is data:
      if (snapshot.exists) {
        // Get all of the messages:
        // console.log(snapshot.val());
        // Save all of the messages into state, merging them with the existing messages:
        setAllMessages({ ...allMessages, ...snapshot.val() });
      }
    });
  }, []);

  return (
    <>
      <Head>
        <meta charSet="utf-8" />
        <title>Public Produce</title>
        <link href="css/normalize.css" rel="stylesheet" />
        <link href="css/style.css" rel="stylesheet" />
      </Head>
      <main>
        <section>
          <h1>
            Public Produce
            <span role="img" aria-labelledby="plant">
              {" "}
              &#x1F331;{" "}
            </span>
          </h1>
          <p>Got produce for anyone to pick and take? Let us know!</p>
          <form
            onSubmit={async (e: any) => {
              e.preventDefault();
              const message = e.target.message.value;
              // Add the message to realtime database:
              await addMessageToRealtimeDB(message);

              // Clear the form:
              e.target.message.value = "";
            }}
            id="message-form"
            className="mb-6"
          >
            <label htmlFor="message">What and where:</label>
            <textarea id="message" placeholder="Example: Sourdough in Hackney."></textarea>
            <button className="btn" type="submit">
              Post to board
            </button>
          </form>
        </section>
        <section>
          <h2>
            Produce Postings
            <span role="img" aria-labelledby="plant">
              {" "}
              &#x1F331;{" "}
            </span>
          </h2>
          <ul className="message-board">
            {/* <Votes /> */}
            {Object.keys(allMessages).map((key, index) => {
              const message = allMessages[key];
              return <Votes key={`votes_${index}`} message={message.message} timestamp={message.timestamp} votes={message.votes} uuid={key} />;
            })}
          </ul>
        </section>
      </main>
    </>
  );
}
