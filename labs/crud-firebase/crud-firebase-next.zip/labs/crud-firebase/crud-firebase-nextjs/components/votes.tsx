import { ref, update, set } from 'firebase/database';
import { getDatabase } from 'firebase/database';
const db = getDatabase();

const updateVoteToRealtimeDB = async (uuid, vote, voteType) => {
  if (voteType === 'upvote') {
    const newRef = ref(db, `messages/${uuid}`);
    return await update(newRef, { votes: vote + 1 });
  } else {
    const newRef = ref(db, `messages/${uuid}`);
    return await update(newRef, { votes: vote - 1 });
  }
};

const deleteMessageInRealtimeDB = async (uuid) => {
  // Delete the message from the realtime database:
  const newRef = ref(db, `messages/${uuid}`);
  return await set(newRef, null);
};

export default function Votes({ message, timestamp, votes, uuid }) {
  // const numberOfVotes = 0;

  return (
    <li key={timestamp}>
      <p>{message}</p>
      <div>
        <p aria-labelledby="number of votes">
          votes: <span id="votes">{votes}</span>
        </p>
        <button
          onClick={async (e: any) => {
            // use the updateVoteToRealtimeDB function to update the votes:
            await updateVoteToRealtimeDB(uuid, votes, 'upvote');
          }}
          type="button"
          id="vote-up"
          aria-labelledby="vote up"
        >
          &#x1F44D;
        </button>
        <button
          onClick={async (e: any) => {
            // use the updateVoteToRealtimeDB function to update the votes:
            await updateVoteToRealtimeDB(uuid, votes, 'downVote');
          }}
          type="button"
          id="vote-down"
          aria-labelledby="vote down"
        >
          &#x1F44E;
        </button>
        <button
          type="button"
          onClick={async (e: any) => {
            // use the deleteMessageInRealtimeDB function to delete the message:
            await deleteMessageInRealtimeDB(uuid);
          }}
          id="delete"
          aria-labelledby="delete"
        >
          &#x1F5D1;
        </button>
      </div>
    </li>
  );
}
