import React from 'react';

export default function Votes() {
  const numberOfVotes = 0;

  return (
    <li>
      <p>test</p>
      <div>
        <p aria-labelledby="number of votes">
          votes: <span id="votes">{numberOfVotes}</span>
        </p>
        <button type="button" id="vote-up" aria-labelledby="vote up">
          &#x1F44D;
        </button>
        <button type="button" id="vote-down" aria-labelledby="vote down">
          &#x1F44E;
        </button>
        <button type="button" id="delete" aria-labelledby="delete">
          &#x1F5D1;
        </button>
      </div>
    </li>
  );
}
