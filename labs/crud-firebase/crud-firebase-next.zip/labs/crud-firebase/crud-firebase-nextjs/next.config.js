module.exports = {
  images: {},
};
