# Bike Wheel 🚴🏻‍♀️

## Instructions

Using CSS animations, spin the bike wheel

You can use the following CSS animation properties

```txt
animation-name
animation-iteration-count
animation-duration
animation-timing-function
animation-fill-mode
```
