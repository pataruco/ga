// Enhance this code using an event object to prevent the form from submitting when the 'Add reminder' button is clicked.
