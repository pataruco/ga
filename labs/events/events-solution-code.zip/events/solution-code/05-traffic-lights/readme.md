# Traffic Lights 🚦

This is your first solo JavaScript lab 🙌 !

Following the 3 **E's pattern (Element, Event, Execution)** solve the following problems:

1. When user `click` on the stop button the top light should be turn from black to red ⚫️ → 🔴
2. When user `click` on the slow button the middle light should turn from black to amber ⚫️ → 🟡
3. When user `click` on the go button the bottom light should turn from black to green ⚫️ → 🟢

Happy coding!
