/*
// function expression version of an IIFE

*/

// function declaration version of an IIFE
