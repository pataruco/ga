const url = 'https://restcountries.com/v3.1/all';
const countriesListElement = document.getElementById('list');
