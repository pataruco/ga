// psuedo code:

// Add event listener on button clicks
// Get name from user in alert box
// Show greeting with user's name
// Show name tag with user's name

'use strict';
