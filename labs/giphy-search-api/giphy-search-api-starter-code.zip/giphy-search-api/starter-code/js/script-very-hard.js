// Implement a gif search using the gify API

// apiKey: i9u5FoDahfPMI2LFAipRD3KXJ45afk0f
// url: https://api.giphy.com/v1/gifs/search?api_key=API_KEY_GOES_HERE&q=SEARCH_TERM_GOES_HERE