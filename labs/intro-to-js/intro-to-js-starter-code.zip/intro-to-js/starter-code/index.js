'use strict';
console.log('working!');

// 1. create a variable called firstName and assign it the value of your first name

// 2. print firstName to the console

// 3. Create a variable called lastName and assign it the value of your last name

// 4. print lastName to the console

// 5. create a variable called age and assign it the value of your age (or any number you like)

// 6. print a string to the console that reads: 'My name is [first name] [last name] and my favourite number is [age]'

// 7. create a variable X and assign it any number

// 8. create a variable Y and assign it any number

// 9. print to the console the total of X and Y

// 10. print to the console the total of X subtracted from Y

// 11. print to the console the total of X multiplied by Y

// 12. create a variable called changeNumber and assign it the number 5 and print it to the console

// 13. re-assign the value of changeNumber to 300 and print it to the console

// 14. uncomment the variables below, concatinate them and print the result to the console

// const fruit = 'Oranges'
// const vegetable = 'potatos'
// const drink = 'cola'
