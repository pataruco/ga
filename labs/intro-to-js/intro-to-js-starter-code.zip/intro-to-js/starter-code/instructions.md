# Intro to JavaScript homework

## Task:

1. Complete the tasks in the javascript file by using a Node.js REPL to see the results

2. Push your code to your own branch of the homework repository
