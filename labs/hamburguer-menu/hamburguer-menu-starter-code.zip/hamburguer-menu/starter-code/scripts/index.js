// grab a reference to all the elements that will control the show/hide of the nav

// loop through each of the nav icon triggers and add an event listener

// create the event handler function to toggle the active state of body
