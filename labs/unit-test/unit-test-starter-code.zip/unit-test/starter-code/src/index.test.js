/* eslint-disable no-undef */
import { fizzbuzz } from './index.js';
