'use strict';
console.log('working!');

// write an if/else statement that takes an age as a parameter
// if the age is equal to or over 17, console log('can drive!')
// if the age is under 17, console log('can not drive!')

// refactor the function into a ternery statement

// write a switch statement
