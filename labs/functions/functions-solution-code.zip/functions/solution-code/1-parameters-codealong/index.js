'use strict';
console.log('working');

// write a function call add
// it should take 2 parameters a and b
// it should console log a + b
// invoke the function with 2 numbers
const add = (a, b) => {
  console.log(a + b);
};

add(2, 3);

// write a function called sayHello
// it should take 1 parameter - we can call it name (or anything else we like)
// it should console log hello + name
// invoke the function with a name

const sayHello = (name) => {
  console.log(`Hello ${name}`);
};

sayHello('Pedro');

// INTRO TO SWITCH STATEMENTS AND CONDITIONALS
// check if the name is a member
// if it is a member return a string to say it is
// if it's not, return a string to say it isn't

const sayHelloToARoyal = (name) => {
  switch (name) {
    case 'Elizabeth':
      console.log('Hello your Majesty');
      break;
    case 'William':
      console.log('Hello your Royal Highness ' + name);
    default:
      sayHello(name);
      break;
  }
};
