// Write a constructor function to replace our `makeCar` function
// earlier.

// function makeCar(model, colour) {
//   let car = {
//     model: model,
//     colour: colour,
//     fuel: 100,
//     drive: function() {
//       this.fuel--;
//       return 'Vroom!';
//     },
//     refuel: function() {
//       this.fuel = 100;
//     }
//   };
//   return car;
// }
