# Score keeper Lab 🧪

This is an advanced JavaScript lab!

Following the 3 **E's pattern (Element, Event, Execution)** solve the following problems:

- Click the buttons to increase or decrease the score.
- If you go below **-10** or above **100**, automatically reset to **0**

Happy coding!
