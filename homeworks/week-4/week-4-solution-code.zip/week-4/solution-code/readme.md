# Animal Drum kit 🥁

This is JavaScript lab is for exercise conditionals (`if`, `else`, `switch`)

Following the 3 **E's pattern (Element, Event, Execution)** solve the following problems:

1. When user `keydown` letter <kbd>A</kbd> the **clap** sound should play
2. When user `keydown` letter <kbd>S</kbd> the **hihat** sound should play
3. When user `keydown` letter <kbd>D</kbd> the **openhat** sound should play
4. When user `keydown` letter <kbd>G</kbd> the **boom** sound should play
5. When user `keydown` letter <kbd>H</kbd> the **ride** sound should play
6. When user `keydown` letter <kbd>J</kbd> the **snare** sound should play
7. When user `keydown` letter <kbd>K</kbd> the **tom** sound should play
8. When user `keydown` letter <kbd>L</kbd> the **link** sound should play

Happy coding!
